<?php
/*
Plugin Name: BD Phone Validator for WooCommerce
Description: Validates Bangladeshi phone numbers (01XXXXXXXXX) at WooCommerce checkout.
Version: 1.0
Author: Rakib Hasan
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Validate Bangladeshi phone number at WooCommerce checkout
add_action('woocommerce_checkout_process', function () {
    $phone = sanitize_text_field($_POST['billing_phone'] ?? '');

    if ($phone && !preg_match('/^01[3-9]\d{8}$/', $phone)) {
        wc_add_notice(__('⚠️ ভুল মোবাইল নম্বর! অনুগ্রহ করে সঠিক ১১ সংখ্যার বাংলাদেশি মোবাইল নম্বর দিন (01XXXXXXXXX)', 'bd-phone-validator'), 'error');
    }
});
